# NS-October-2021

This repository contains all the notes for the classes held in October Batch
